Page({
  data: {
    URL: 'http://www.dr0759.cn/h5/index.html#!/index/401',
  },
  onLoad(query) {
    // 页面加载
    console.info(`Page onLoad with query: ${JSON.stringify(query)}`);
  },
  onReady() {
    my.getAuthCode({
  scopes: 'auth_user',
  success: (res) => {
    this.setData({
      URL: 'http://weixin.gdbkyz.com/NewQzsfyTest/h5/dist/#!/index/portal',
    })
    console.info(res)

    console.info('url:',this.data.URL)
    this.onShow()
  },
});
  },
  onShow() {
    // 页面显示
  },
  onHide() {
    // 页面隐藏
  },
  onUnload() {
    // 页面被关闭
  },
  onTitleClick() {
    // 标题被点击
  },
  onPullDownRefresh() {
    // 页面被下拉
  },
  onReachBottom() {
    // 页面被拉到底部
  },
  onShareAppMessage() {
    // 返回自定义分享信息
    return {
      title: '湛江中心人民医院',
      desc: 'My App description',
      path: 'pages/index/index',
    };
  },
});
